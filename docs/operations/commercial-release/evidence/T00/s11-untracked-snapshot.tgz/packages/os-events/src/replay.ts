/**
 * S11 replay rules shared by the command services. They follow the os-work
 * contract (`WorkCommandService.acceptedReplay`):
 *
 * - The caller authorizes the current actor for the current command before
 *   asking for a stored result.
 * - A stored result is returned only to the member who produced it. Any other
 *   caller, including one who guesses the key, gets CONFLICT and never sees the
 *   stored body.
 * - A stored row with no bound actor (written before this rule) is not
 *   replayed to anyone. It also is not re-executed: the caller gets CONFLICT.
 */

/** The stored form of a command result: the result plus the member who produced it. */
export function stampReplayActor(result: object, actorMemberId: string): Record<string, unknown> {
  return { ...(result as Record<string, unknown>), actorMemberId };
}

/**
 * Returns the stored result for `actorMemberId`, without the bound actor.
 * Throws CONFLICT when the row belongs to someone else or names no one.
 */
export function replayForActor<T>(
  stored: Record<string, unknown> | null | undefined,
  actorMemberId: string,
): T {
  const bound = stored?.actorMemberId;
  if (!stored || typeof bound !== 'string' || bound.length === 0 || bound !== actorMemberId) {
    throw new Error('CONFLICT');
  }
  const { actorMemberId: _actor, ...result } = stored;
  return result as T;
}

/** True when a write lost the race on a unique key (Postgres P2002 or the memory-store equivalent). */
export function isIdempotencyConflict(err: unknown): boolean {
  if (!err || typeof err !== 'object') return false;
  const code = (err as { code?: string }).code;
  if (code === 'P2002') return true;
  const message = err instanceof Error ? err.message : '';
  return message === 'IDEMPOTENCY_CONFLICT' || /Unique constraint/i.test(message);
}
